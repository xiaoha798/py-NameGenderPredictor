# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 11:58:26 2020

@author: Hadrien
"""


from .NameGenderPredictor import predict_gender as predict_gender